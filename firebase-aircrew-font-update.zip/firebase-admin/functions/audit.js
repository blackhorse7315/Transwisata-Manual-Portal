'use strict';
const { Parser } = require('htmlparser2');
const { diffWordsWithSpace } = require('diff');
function text(html) {
  let out = '', ignored = 0;
  const parser = new Parser({
    onopentag(name) { if (['script', 'style'].includes(name)) ignored++; if (['p','br','div','li','tr','h1','h2','h3'].includes(name)) out += '\n'; },
    ontext(value) { if (!ignored) out += value; },
    onclosetag(name) { if (['script','style'].includes(name)) ignored--; if (['td','th'].includes(name)) out += '\t'; }
  }, { decodeEntities: true });
  parser.write(String(html || '')); parser.end();
  return out.replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function layoutCounts(manual) {
  const sizes={A4:[210,297],A3:[297,420],A5:[148,210],Letter:[215.9,279.4],Legal:[215.9,355.6],Tabloid:[279.4,431.8]};
  const capacity=(kind,i)=>{
    const front=manual.front?.[kind]||{}, page={...front,...front.pageMeta?.[kind+'-'+i]}, layout=page.layout||manual.layout||{size:'A4',orientation:'portrait'}, size=sizes[layout.size]||sizes.A4;
    const height=Math.round((layout.orientation==='landscape'?size[0]:size[1])*96/25.4);
    const font=parseFloat({...front.paragraphFormat,...page.paragraphFormat}['font-size'])||13;return Math.max(3,Math.floor(22*Math.max(100,height-267)/856*29.55/(font*1.35+12))); 
  };
  const count=(total,kind)=>{let sum=0;for(let i=0;i<10000;i++){let cap=capacity(kind,i);sum+=cap;let reserve=kind==='loep'&&manual.front?.loep?.signature?.enabled!==false?Math.min(8,cap-1):0;if(sum-reserve>=total)return i+1;}throw Error('Too many generated pages.');};
  const hidden=manual.hiddenFront||[],frontCount=['cover','letter','dkppu','control','record'].filter(id=>!hidden.includes(id)&&(id!=='control'||manual.frontTemplateVersion===1)).length;
  let headings=0;
  for(const page of manual.pages||[]){const seen=new Set([String(page.title||'').trim().toLowerCase()]);for(const match of (page.html||'').matchAll(/<h([123])\b[^>]*>([\s\S]*?)<\/h\1>/gi)){const title=text(match[2]).trim().toLowerCase();if(title&&!seen.has(title)){seen.add(title);headings++;}}}
  let loep=hidden.includes('loep')?0:1,toc=hidden.includes('toc')?0:1;
  for(let i=0;i<10000;i++){const total=frontCount+(manual.pages||[]).length+loep+toc,nextLoep=loep?count(total,'loep'):0,nextToc=toc?count(total+headings,'toc'):0;if(nextLoep===loep&&nextToc===toc)return{loep,toc};loep=nextLoep;toc=nextToc;}
  throw Error('Invalid page layout.');
}
function pageMap(manual, part) {
  const result=new Map();if(!manual)return result;const counts=layoutCounts(manual),records=(manual.pages||[]).filter(p=>p.section==='record');
  for(const id of ['cover','letter','dkppu','control','loep','record','toc']) {
    const page=manual.front?.[id]||{},hidden=manual.hiddenFront?.includes(id)||(id==='control'&&manual.frontTemplateVersion!==1);
    if(!hidden){if(['loep','toc'].includes(id)){for(let i=0;i<counts[id];i++){const pageId=id+'-'+i;result.set(pageId,{...page,...page.pageMeta?.[pageId],html:page.edits?.[pageId]||'',edits:undefined,pageMeta:undefined,pageBars:undefined,bars:page.pageBars?.[pageId]||[],chapter:'F',title:id==='loep'?'List of Effective Pages':'Table of Contents',number:(id==='loep'?'LoEP':'TOC')+' - '+(i+1)});}}
    else result.set(id,{...page,chapter:id==='record'?'00':'F',title:{control:'Document Control',cover:'Front page',letter:'Surat Pengantar',dkppu:'Control Page — DKPPU',record:'Record of Revision'}[id]||id,number:id==='record'?'ROR - 1':id});}
    if(id==='record')records.forEach((page,i)=>result.set(page.id,{...page,number:'ROR - '+(i+1+(hidden?0:1))}));
  }
  const folios=new Map();let folio=Number(manual.start)||1;for(const page of manual.pages||[]){if(page.section==='record')continue;if(page.numbering?.mode==='restart')folio=Number(page.numbering.start)||1;folios.set(page.id,folio++);result.set(page.id,{...page});}
  let index=0;for(const [id,page] of result){if(!id.startsWith('loep-')&&!id.startsWith('toc-')&&id!=='record'&&page.section!=='record')page.number=['letter','dkppu'].includes(id)?'—':String(manual.number||'OM-{part}/{chapter}-{page}').replace(/\{(\w+)\}/g,(match,key)=>({ref:manual.ref,part:manual.code||part||manual.part,chapter:page.chapter,page:folios.get(id)??index+Number(manual.start||1),total:result.size,revision:page.rev,date:page.date,issue:manual.issue})[key]??match);index++;}return result;
}
function metadata(page) {
  if (!page) return null;
  const copy = {...page}; delete copy.html; delete copy.number;
  // Keep large image data out of the audit, but detect image/logo changes.
  for (const key of ['image', 'logo']) if (copy[key]) copy[key] = require('node:crypto').createHash('sha256').update(String(copy[key])).digest('hex');
  function compact(value) {
    if (Array.isArray(value)) return value.map(compact);
    if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(k => [k, /^(image|stamp|signature|logo|boxImage|approvalImage)$/.test(k) && typeof value[k] === 'string' && value[k].length > 200 ? require('node:crypto').createHash('sha256').update(value[k]).digest('hex') : compact(value[k])]));
    return value;
  }
  return compact(copy);
}
function revisions(before, after) {
  const entries = [];
  for (const part of new Set([...Object.keys(before?.manuals||{}),...Object.keys(after.manuals||{})])) {
    const oldManual = before?.manuals?.[part], newManual = after.manuals[part];
    const manualName=newManual?.label||newManual?.code||oldManual?.label||oldManual?.code||(/^[ABCD]$/.test(part)?'OM '+part:part);
    const oldPages = pageMap(oldManual,part), newPages = pageMap(newManual,part);
    for (const id of new Set([...oldPages.keys(), ...newPages.keys()])) {
      const old = oldPages.get(id), next = newPages.get(id);
      if (JSON.stringify(old) === JSON.stringify(next)) continue;
      const changes = diffWordsWithSpace(text(old?.html), text(next?.html));
      const added = changes.filter(c => c.added).map(c => c.value), removed = changes.filter(c => c.removed).map(c => c.value);
      const oldMeta = metadata(old) || {}, newMeta = metadata(next) || {};
      const fields = [...new Set([...Object.keys(oldMeta), ...Object.keys(newMeta)])].filter(k => JSON.stringify(oldMeta[k]) !== JSON.stringify(newMeta[k]));
      if(old?.html!==next?.html&&!added.length&&!removed.length)fields.push('text-format');
      entries.push({ manual: part, manualName, pageId: id, page: next?.number || old?.number || id, chapter: String(next?.chapter || old?.chapter || 'F'), title: String(next?.title || old?.title || id), action: !old ? 'page-added' : !next ? 'page-deleted' : 'page-edited', added, removed, fields });
    }
    const omitPages = m => { const copy = {...(m || {})}; delete copy.pages; delete copy.front; delete copy.deletedPages; delete copy.frontTemplateVersion; return metadata(copy); };
    const oldSettings = omitPages(oldManual), newSettings = omitPages(newManual);
    const fields = [...new Set([...Object.keys(oldSettings), ...Object.keys(newSettings)])].filter(k => JSON.stringify(oldSettings[k]) !== JSON.stringify(newSettings[k]));
    if (fields.length) entries.push({manual:part,manualName,pageId:'settings',page:'—',chapter:'—',title:'Manual settings',action:'settings-edited',added:[],removed:[],fields});
  }
  return entries;
}
// Split complete text into small Firestore documents instead of truncating the log.
function fragments(entry) {
  const result = [];
  for (const kind of ['added','removed']) for (const [segment,value] of entry[kind].entries()) for (let i = 0; i < value.length; i += 20000) result.push({kind,segment,text:value.slice(i,i+20000)});
  return result;
}
module.exports = { text, revisions, fragments, pageMap };
