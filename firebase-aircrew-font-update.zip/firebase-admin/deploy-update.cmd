@echo off
setlocal
cd /d "%~dp0"
set "FUNCTIONS_DISCOVERY_TIMEOUT=60"
call npm --prefix functions ci
if errorlevel 1 goto failed
call firebase deploy --only functions:manual-portal --project ecrew-absensi-183ac
if errorlevel 1 goto failed
echo.
echo Deployment finished. Refresh the portal with Ctrl + Shift + R.
pause
exit /b 0
:failed
echo.
echo Deployment failed. Review the error above. If login is required, run firebase login.
pause
exit /b 1
