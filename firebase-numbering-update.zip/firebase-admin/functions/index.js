'use strict';
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { gunzipSync } = require('node:zlib');
const { createHash } = require('node:crypto');
const access = require('./access');
const audit = require('./audit');
initializeApp();
const db = getFirestore(), auth = getAuth();
const root = db.doc('operationsManualPortal/transwisata');
const meta = root.collection('workspace').doc('current');
const memberRef = uid => root.collection('members').doc(uid);
const versionRef = version => root.collection('versions').doc(version);
const options = { region: 'asia-southeast2', memory: '512MiB', timeoutSeconds: 120, maxInstances: 5 };
const call = fn => onCall(options, async req => {
  try { return await fn(req); } catch (e) {
    if (e instanceof HttpsError) throw e;
    // Never expose backend stack traces, provider response bodies or submitted passwords.
    if (e.code === 'auth/email-already-exists') throw new HttpsError('already-exists', 'Username sudah digunakan.');
    throw new HttpsError('failed-precondition', e.message?.startsWith('auth/') ? 'Operasi akun gagal.' : (e.message || 'Operasi gagal.'));
  }
});
async function member(req, admin = false) {
  if (!req.auth || req.auth.token.firebase?.sign_in_provider === 'anonymous') throw new HttpsError('unauthenticated', 'Silakan login.');
  const profile = (await memberRef(req.auth.uid).get()).data();
  try { admin ? access.requireAdmin(profile) : access.requireMember(profile); } catch (_) { throw new HttpsError('permission-denied', 'Akun tidak memiliki akses.'); }
  return {uid:req.auth.uid, ...profile};
}
function publicProfile(profile) { return { uid:profile.uid, name:profile.name, username:profile.username, role:profile.role, active:profile.active }; }
function id(value) { if (typeof value !== 'string' || !/^[\w-]{10,90}$/.test(value)) throw Error('Invalid identifier.'); return value; }
function name(value) { const s=String(value||'').trim(); if(s.length<2||s.length>100)throw Error('Nama harus 2–100 karakter.'); return s; }
function password(value) { if(typeof value!=='string'||value.length<8||value.length>128)throw Error('Password harus 8–128 karakter.'); return value; }
exports.portalSession = call(async req => publicProfile(await member(req)));
exports.portalListUsers = call(async req => {
  await member(req, true);
  const rows = await root.collection('members').where('active','==',true).limit(500).get();
  return {users:rows.docs.map(d=>publicProfile({uid:d.id,...d.data()}))};
});
exports.portalManageUser = call(async req => {
  const actor = await member(req,true), data=req.data||{};
  if (data.action==='add') {
    const username=access.username(data.username), displayName=name(data.name);
    const user=await auth.createUser({email:access.emailFor(username),password:password(data.password),displayName});
    try {
      await memberRef(user.uid).create({name:displayName,username,role:'user',active:true,createdAt:FieldValue.serverTimestamp(),createdBy:actor.uid});
    } catch(e) { await auth.deleteUser(user.uid); throw e; }
    return {user:publicProfile({uid:user.uid,name:displayName,username,role:'user',active:true})};
  }
  const uid=id(data.uid), ref=memberRef(uid), profile=(await ref.get()).data();
  if(!profile||!profile.active)throw new HttpsError('not-found','User tidak ditemukan.');
  access.editableUser(profile,actor.uid,uid);
  if(data.action==='delete') {
    // Disable first; retain UID/name for historical attribution. Authentication is
    // revoked and membership denied immediately, even for an old ID token.
    await ref.update({active:false,deletedAt:FieldValue.serverTimestamp(),deletedBy:actor.uid});
    await auth.updateUser(uid,{disabled:true}); await auth.revokeRefreshTokens(uid);
    return {deleted:true};
  }
  if(data.action!=='edit')throw Error('Unknown account action.');
  const username=access.username(data.username), displayName=name(data.name);
  const update={email:access.emailFor(username),displayName};
  if(data.password)update.password=password(data.password);
  await auth.updateUser(uid,update);
  await ref.update({name:displayName,username,updatedAt:FieldValue.serverTimestamp(),updatedBy:actor.uid});
  if(data.password)await auth.revokeRefreshTokens(uid);
  return {updated:true};
});
exports.portalStartUpload = call(async req => {
  const actor=await member(req), data=req.data||{}, version=id(data.version);
  if(!Number.isInteger(data.count)||data.count<1||data.count>500||!['gzip','json'].includes(data.encoding))throw Error('Invalid upload manifest.');
  await versionRef(version).create({owner:actor.uid,count:data.count,encoding:data.encoding,status:'staging',createdAt:FieldValue.serverTimestamp()});
  return {version};
});
exports.portalUploadChunk = call(async req => {
  const actor=await member(req),data=req.data||{},ref=versionRef(id(data.version));
  if(!Number.isInteger(data.index)||data.index<0||typeof data.payload!=='string'||data.payload.length>400000||!/^[A-Za-z0-9+/=]*$/.test(data.payload))throw Error('Invalid upload chunk.');
  await db.runTransaction(async tx=>{
    const doc=await tx.get(ref),stage=doc.data();
    if(stage?.owner!==actor.uid||stage.status!=='staging'||data.index>=stage.count)throw new HttpsError('permission-denied','Upload tidak tersedia.');
    tx.set(ref.collection('chunks').doc(String(data.index).padStart(5,'0')),{payload:data.payload});
  });
  return {uploaded:true};
});
async function readWorkspace(ref, manifest) {
  const chunks=[];
  for(let i=0;i<manifest.count;i+=20){const docs=await db.getAll(...Array.from({length:Math.min(20,manifest.count-i)},(_,j)=>ref.collection('chunks').doc(String(i+j).padStart(5,'0'))));for(const doc of docs){if(!doc.exists)throw Error('Upload belum lengkap.');chunks.push(doc.data().payload);}}
  let bytes=Buffer.from(chunks.join(''),'base64');
  if(manifest.encoding==='gzip')bytes=gunzipSync(bytes,{maxOutputLength:150*1024*1024});
  if(bytes.length>150*1024*1024)throw Error('Manual terlalu besar.');
  const workspace=JSON.parse(bytes.toString('utf8'));
  if(workspace.schema!==1||!'ABCD'.split('').every(p=>Array.isArray(workspace.manuals?.[p]?.pages)))throw Error('Format manual tidak valid.');
  return workspace;
}
async function writeRecords(records) {
  for(let i=0;i<records.length;i+=400){const batch=db.batch();for(const [ref,data] of records.slice(i,i+400))batch.set(ref,data);await batch.commit();}
}
exports.portalCommitUpload = call(async req => {
  const actor=await member(req), data=req.data||{}, ref=versionRef(id(data.version));
  const expected=data.expected??null;
  const [manifest,previous]=await db.runTransaction(async tx=>{
    const stage=(await tx.get(ref)).data(),old=(await tx.get(meta)).data()||null;
    if(stage?.owner!==actor.uid)throw new HttpsError('permission-denied','Upload tidak tersedia.');
    if(stage.status==='committed')return [stage, {alreadyCommitted:true}];
    if(stage.status!=='staging')throw Error('Upload sedang diproses; periksa Cloud Sync sebelum mencoba lagi.');
    if((old?.version||null)!==expected)throw Error('Cloud changed on another device. Load cloud before uploading again.');
    tx.update(ref,{status:'committing'});return [stage,old];
  });
  if(previous?.alreadyCommitted)return {version:data.version};
  try {
    const after=await readWorkspace(ref,manifest);
    const before=previous ? await readWorkspace(versionRef(previous.version),previous) : null;
    const entries=audit.revisions(before,after),records=[];
    for(const [i,entry] of entries.entries()){
      const entryRef=ref.collection('audit').doc(String(i).padStart(6,'0')),parts=audit.fragments(entry);
      const {added,removed,...summary}=entry;
      records.push([entryRef,{...summary,fragments:parts.length}]);
      for(const [j,fragment] of parts.entries())records.push([entryRef.collection('fragments').doc(String(j).padStart(6,'0')),fragment]);
    }
    await writeRecords(records);
    await db.runTransaction(async tx=>{
      const old=(await tx.get(meta)).data()||null,profile=(await tx.get(memberRef(actor.uid))).data();
      access.requireMember(profile);
      if((old?.version||null)!==expected)throw Error('Cloud changed on another device. Load cloud before uploading again.');
      const updatedAt=FieldValue.serverTimestamp();
      tx.set(meta,{version:data.version,count:manifest.count,encoding:manifest.encoding,schema:1,updatedAt,updatedBy:actor.uid,previousVersion:old?.version||null,previousCount:old?.count||0});
      tx.update(ref,{status:'committed',committedAt:updatedAt,actor:{uid:actor.uid,name:actor.name,username:actor.username},auditCount:entries.length,manuals:[...new Set(entries.map(e=>e.manual))],checksum:createHash('sha256').update(JSON.stringify(after)).digest('hex')});
    });
    // Versions are retained: audit detail and historical text must not be deleted
    // by the old client's two-version cleanup routine.
    return {version:data.version,auditCount:entries.length};
  }catch(e){await ref.update({status:'failed'}).catch(()=>{});throw e;}
});
exports.portalListRevisions = call(async req=>{
  await member(req);
  const cursor=req.data?.cursor;
  let query=root.collection('versions').orderBy('createdAt','desc').limit(20);
  if(cursor){const doc=await versionRef(id(cursor)).get();if(!doc.exists)throw Error('Invalid cursor.');query=query.startAfter(doc);}
  const docs=await query.get(),rows=[];
  for(const doc of docs.docs){const version=doc.data();if(version.status!=='committed')continue;const entries=await doc.ref.collection('audit').orderBy('__name__').get();for(const entry of entries.docs)rows.push({version:doc.id,entryId:entry.id,...entry.data(),actor:version.actor,date:version.committedAt?.toDate().toISOString()||null});}
  return {rows,cursor:docs.size===20?docs.docs.at(-1).id:null};
});
exports.portalRevisionDetail = call(async req=>{
  await member(req);const version=id(req.data?.version),entryId=String(req.data?.entryId||'');
  if(!/^\d{6}$/.test(entryId))throw Error('Invalid audit entry.');
  const ref=versionRef(version);if((await ref.get()).data()?.status!=='committed')throw Error('Revision belum tersimpan.');
  const fragments=await ref.collection('audit').doc(entryId).collection('fragments').orderBy('__name__').get();
  const combine=kind=>{const groups=new Map();for(const doc of fragments.docs){const part=doc.data();if(part.kind===kind)groups.set(part.segment,(groups.get(part.segment)||'')+part.text);}return [...groups.values()].join('\n…\n');};
  return {added:combine('added'),removed:combine('removed')};
});
