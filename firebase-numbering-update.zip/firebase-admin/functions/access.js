'use strict';
function username(value) {
  const result = String(value || '').trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9._-]{2,39}$/.test(result)) throw Error('Username must contain 3–40 letters, numbers, dots, hyphens or underscores.');
  return result;
}
function emailFor(value) { return username(value) + '@manual.transwisata.internal'; }
function requireMember(profile) {
  if (!profile || profile.active !== true || !['admin', 'user'].includes(profile.role)) throw Error('Access denied.');
  return profile;
}
function requireAdmin(profile) {
  requireMember(profile);
  if (profile.role !== 'admin') throw Error('Administrator access required.');
  return profile;
}
function editableUser(profile, actorUid, targetUid) {
  if (targetUid === actorUid || profile?.role === 'admin') throw Error('Administrator accounts cannot be changed through this menu.');
}
module.exports = { username, emailFor, requireMember, requireAdmin, editableUser };
