const test=require('node:test'),fs=require('node:fs');
const {initializeTestEnvironment,assertFails,assertSucceeds}=require('@firebase/rules-unit-testing');
const {doc,getDoc,setDoc}=require('firebase/firestore');
test('portal rules enforce membership, protect profiles/audit and preserve unrelated app policy',async()=>{
  const env=await initializeTestEnvironment({projectId:'demo-transwisata',firestore:{rules:fs.readFileSync(__dirname+'/../firestore.rules','utf8')}});
  try{
    const root='operationsManualPortal/transwisata';
    await env.withSecurityRulesDisabled(async context=>{
      const db=context.firestore();
      await setDoc(doc(db,root+'/members/editor'),{active:true,role:'user'});
      await setDoc(doc(db,root+'/members/admin'),{active:true,role:'admin'});
      await setDoc(doc(db,root+'/members/disabled'),{active:false,role:'user'});
      await setDoc(doc(db,root+'/workspace/current'),{version:'legacy'});
      await setDoc(doc(db,root+'/versions/legacy/chunks/00000'),{payload:'manual'});
      await setDoc(doc(db,root+'/versions/legacy/audit/000000'),{actor:'editor'});
      await setDoc(doc(db,'unrelated/example'),{value:1});
    });
    const editor=env.authenticatedContext('editor',{firebase:{sign_in_provider:'password'}}).firestore();
    const admin=env.authenticatedContext('admin',{firebase:{sign_in_provider:'password'}}).firestore();
    const anon=env.authenticatedContext('anonymous',{firebase:{sign_in_provider:'anonymous'}}).firestore();
    const outsider=env.authenticatedContext('outsider',{firebase:{sign_in_provider:'password'}}).firestore();
    const disabled=env.authenticatedContext('disabled',{firebase:{sign_in_provider:'password'}}).firestore();
    await assertSucceeds(getDoc(doc(editor,root+'/workspace/current')));
    await assertSucceeds(getDoc(doc(admin,root+'/versions/legacy/chunks/00000')));
    for(const db of [anon,outsider,disabled,env.unauthenticatedContext().firestore()])await assertFails(getDoc(doc(db,root+'/workspace/current')));
    await assertFails(setDoc(doc(editor,root+'/members/editor'),{active:true,role:'admin'}));
    await assertFails(setDoc(doc(admin,root+'/members/new-user'),{active:true,role:'user'}));
    await assertFails(setDoc(doc(editor,root+'/workspace/current'),{version:'forged'}));
    await assertFails(setDoc(doc(editor,root+'/versions/legacy/audit/000000'),{actor:'admin'}));
    await assertFails(getDoc(doc(editor,root+'/members/admin')));
    await assertFails(getDoc(doc(editor,root+'/versions/legacy/audit/000000')));
    await assertSucceeds(getDoc(doc(anon,'unrelated/example')));
    await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(),'unrelated/example')));
  }finally{await env.cleanup();}
});
