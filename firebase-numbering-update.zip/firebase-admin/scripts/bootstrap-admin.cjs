// Run privately after Google Application Default Credentials are available.
// The password is requested without echo; it is never committed or logged.
const {initializeApp,applicationDefault}=require('../functions/node_modules/firebase-admin/app');
const {getAuth}=require('../functions/node_modules/firebase-admin/auth');
const {getFirestore,FieldValue}=require('../functions/node_modules/firebase-admin/firestore');
initializeApp({credential:applicationDefault(),projectId:'ecrew-absensi-183ac'});
function secret(){return new Promise((resolve,reject)=>{
  if(!process.stdin.isTTY)return reject(Error('Run this script in an interactive terminal.'));
  let value='';process.stdout.write('Initial admin password: ');process.stdin.setRawMode(true);process.stdin.resume();
  function input(chunk){for(const c of chunk.toString()){
    if(c==='\u0003'){cleanup();reject(Error('Cancelled'));return;}
    if(c==='\r'||c==='\n'){cleanup();resolve(value);return;}
    if(c==='\u007f'){value=value.slice(0,-1);continue;}value+=c;
  }}
  function cleanup(){process.stdin.setRawMode(false);process.stdin.pause();process.stdin.off('data',input);process.stdout.write('\n');}
  process.stdin.on('data',input);
});}
(async()=>{
  const auth=getAuth(),db=getFirestore(),email='admin@manual.transwisata.internal';
  // Do not silently reset an existing account's credential.
  let existing=await auth.getUserByEmail(email).catch(e=>{if(e.code==='auth/user-not-found')return null;throw e;});
  if(existing)throw Error('Admin already exists. Review its membership instead of resetting its password.');
  const value=await secret();if(value.length<8)throw Error('Password must have at least 8 characters.');
  const user=await auth.createUser({email,password:value,displayName:'Administrator'});
  try{await db.doc('operationsManualPortal/transwisata/members/'+user.uid).create({name:'Administrator',username:'admin',role:'admin',active:true,createdAt:FieldValue.serverTimestamp()});}
  catch(e){await auth.deleteUser(user.uid);throw e;}
  console.log('Admin account created successfully. No manual data was changed.');
})().catch(e=>{console.error(e.code||e.message);process.exitCode=1;});
