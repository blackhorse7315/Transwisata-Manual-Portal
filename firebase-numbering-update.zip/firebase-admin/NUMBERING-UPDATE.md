# Numbering update

The portal UI uses LoEP - 1, ROR - 1, TOC - 1 and independent restart/continue content page sequences. Deploy this backend update so newly saved revision records use the same numbering and page order. Earlier revision logs remain unchanged.

Extract this package and replace the previous firebase-admin source folder. In Windows CMD, open that folder and run:

```cmd
set FUNCTIONS_DISCOVERY_TIMEOUT=60
npx firebase-tools deploy --only functions:manual-portal --project ecrew-absensi-183ac
```

This deploys the existing manual-portal codebase; Firebase users and manual snapshots are retained.
