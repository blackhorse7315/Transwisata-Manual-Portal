const test=require('node:test'),assert=require('node:assert/strict');
const {revisions,text,fragments}=require('./audit');
function workspace(){return{schema:1,manuals:Object.fromEntries('ABCD'.split('').map(part=>[part,{part,ref:'OM-'+part,number:'OM-{part}/{chapter}-{page}',start:1,front:{cover:{rev:'0',date:'2026-10-11'},loep:{pageMeta:{'loep-0':{rev:'0',date:'2026-10-11'}}}},pages:[{id:'p1',title:'GENERAL',chapter:'1',html:'<p>The pilot checks the aircraft.</p>',rev:'0',date:'2026-10-11'}]}]))}}
test('records actor-independent additions, deletions, chapter and page without inventing edits in other manuals',()=>{
  const before=workspace(),after=structuredClone(before);after.manuals.A.pages[0].html='<p>The captain inspects the aircraft.</p>';
  const rows=revisions(before,after);assert.equal(rows.length,1);assert.equal(rows[0].manual,'A');assert.equal(rows[0].chapter,'1');assert.match(rows[0].page,/OM-A\/1-7/);assert.match(rows[0].added.join(' '),/captain inspects/);assert.match(rows[0].removed.join(' '),/pilot checks/);
});
test('page deletion retains the removed text and metadata',()=>{
  const before=workspace(),after=structuredClone(before);after.manuals.B.pages=[];const row=revisions(before,after).find(r=>r.manual==='B');assert.equal(row.action,'page-deleted');assert.match(row.removed.join(''),/aircraft/);
});
test('revision/date change remains scoped to its LOEP page',()=>{
  const before=workspace(),after=structuredClone(before);after.manuals.A.front.loep.pageMeta['loep-0'].rev='1';const rows=revisions(before,after);assert.equal(rows.length,1);assert.equal(rows[0].page,'LoEP/F-1');assert.deepEqual(rows[0].fields,['rev']);
});
test('HTML extraction decodes entities and excludes executable/style text',()=>assert.equal(text('<p>A &amp; B</p><script>secret</script><style>x</style><p>C</p>'),'A & B\nC'));
test('audit fragments preserve complete long text',()=>{
  const entry={added:['x'.repeat(65001)],removed:['old']};const parts=fragments(entry);assert.equal(parts.filter(p=>p.kind==='added').map(p=>p.text).join(''),entry.added[0]);assert(parts.every(p=>p.text.length<=20000));
});
