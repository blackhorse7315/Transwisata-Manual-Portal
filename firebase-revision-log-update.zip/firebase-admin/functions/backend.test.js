const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const store=new Map(),accounts=new Map();let serial=0,clock='2026-10-11T08:43:37Z';
Date.prototype.toDate=function(){return this;};
const clone=v=>v==null?v:structuredClone(v);
function ref(path){return {path,id:path.split('/').at(-1),collection:name=>collection(path+'/'+name),get:async()=>snapshot(path),create:async data=>{if(store.has(path))throw Error('already exists');store.set(path,clone(data));},set:async data=>store.set(path,clone(data)),update:async data=>{if(!store.has(path))throw Error('missing');store.set(path,{...store.get(path),...clone(data)});}};}
function snapshot(path){return{id:path.split('/').at(-1),exists:store.has(path),data:()=>clone(store.get(path)),ref:ref(path)};}
function collection(path){const query=(key='__name__',direction='asc',limit=Infinity,after=null)=>({doc:id=>ref(path+'/'+id),orderBy:(k,d='asc')=>query(k,d,limit,after),limit:n=>query(key,direction,n,after),startAfter:d=>query(key,direction,limit,d.ref.path),get:async()=>{let docs=[...store.keys()].filter(p=>p.startsWith(path+'/')&&!p.slice(path.length+1).includes('/')).map(snapshot);docs.sort((a,b)=>{let x=key==='__name__'?a.id:a.data()[key],y=key==='__name__'?b.id:b.data()[key];return (x<y?-1:x>y?1:0)*(direction==='desc'?-1:1)});if(after)docs=docs.slice(docs.findIndex(d=>d.ref.path===after)+1);docs=docs.slice(0,limit);return{docs,size:docs.length};}});return query();}
const db={doc:ref,getAll:async(...refs)=>refs.map(r=>snapshot(r.path)),batch:()=>{let writes=[];return{set:(r,d)=>writes.push([r.path,clone(d)]),commit:async()=>writes.forEach(([r,d])=>store.set(r,d))}},runTransaction:async fn=>{const writes=[];const result=await fn({get:async r=>snapshot(r.path),set:(r,d)=>writes.push([r.path,clone(d)]),update:(r,d)=>writes.push([r.path,{...store.get(r.path),...clone(d)}])});writes.forEach(([r,d])=>store.set(r,d));return result;}};
const auth={createUser:async data=>{const uid='created-user-'+(++serial);accounts.set(uid,data);return{uid}},deleteUser:async uid=>accounts.delete(uid),updateUser:async(uid,d)=>accounts.set(uid,{...accounts.get(uid),...d}),revokeRefreshTokens:async()=>{}};
class HttpsError extends Error{constructor(code,message){super(message);this.code=code;}}
const box={exports:{},Buffer,require:name=>{
  if(name==='firebase-functions/v2/https')return{onCall:(_,fn)=>fn,HttpsError};
  if(name==='firebase-admin/app')return{initializeApp(){}};
  if(name==='firebase-admin/auth')return{getAuth:()=>auth};
  if(name==='firebase-admin/firestore')return{getFirestore:()=>db,FieldValue:{serverTimestamp:()=>new Date(clock)}};
  return require(name);
}};vm.createContext(box);vm.runInContext(fs.readFileSync(__dirname+'/index.js','utf8'),box);const api=box.exports;
const root='operationsManualPortal/transwisata',admin={uid:'initial-admin-uid',token:{firebase:{sign_in_provider:'password'}}},user={uid:'normal-user-uid',token:{firebase:{sign_in_provider:'password'}}};
store.set(root+'/members/'+admin.uid,{name:'Admin',username:'admin',role:'admin',active:true});store.set(root+'/members/'+user.uid,{name:'Captain',username:'captain',role:'user',active:true});
function workspace(content){return{schema:1,manuals:Object.fromEntries('ABCD'.split('').map(part=>[part,{title:'Operations Manual',number:'OM-{part}/{chapter}-{page}',start:1,front:{},pages:[{id:'page-12345',title:'GENERAL',chapter:'1',html:part==='A'?content:'<p>unchanged</p>'}]}]))};}
test('anonymous and non-members cannot sign in or upload; a user cannot manage other users',async()=>{
  await assert.rejects(api.portalSession({auth:{uid:'anon',token:{firebase:{sign_in_provider:'anonymous'}}}}),e=>e.code==='unauthenticated');
  await assert.rejects(api.portalStartUpload({auth:{uid:'intruder',token:{}},data:{}}),e=>e.code==='permission-denied');
  await assert.rejects(api.portalManageUser({auth:user,data:{action:'add'}}),e=>e.code==='permission-denied');
  const profile=await api.portalSession({auth:user});assert.equal(profile.username,'captain');assert(!('password' in profile));
});
test('admin creates, updates and deletes user access without storing passwords in Firestore',async()=>{
  const result=await api.portalManageUser({auth:admin,data:{action:'add',name:'New Captain',username:'new.captain',password:'test-only-value'}});
  const uid=result.user.uid;assert.equal(store.get(root+'/members/'+uid).role,'user');assert(!('password' in store.get(root+'/members/'+uid)));
  await api.portalManageUser({auth:admin,data:{action:'edit',uid,name:'Edited Captain',username:'edited.captain',password:''}});
  assert.equal(accounts.get(uid).password,'test-only-value');assert.equal(store.get(root+'/members/'+uid).username,'edited.captain');
  await api.portalManageUser({auth:admin,data:{action:'delete',uid}});assert.equal(store.get(root+'/members/'+uid).active,false);assert.equal(accounts.get(uid).disabled,true);
  await assert.rejects(api.portalSession({auth:{uid,token:{firebase:{sign_in_provider:'password'}}}}),e=>e.code==='permission-denied');
});
test('legacy snapshot migration, owner isolation, server actor/date, full audit and conflict protection',async()=>{
  const oldVersion='legacy-version-12345',previous=workspace('<p>The pilot checks the aircraft.</p>');
  store.set(root+'/workspace/current',{version:oldVersion,count:1,encoding:'json'});
  store.set(root+'/versions/'+oldVersion+'/chunks/00000',{payload:Buffer.from(JSON.stringify(previous)).toString('base64')});
  const version='new-version-12345',next=workspace('<p>The captain inspects the aircraft.</p>');
  await api.portalStartUpload({auth:user,data:{version,count:1,encoding:'json'}});
  await assert.rejects(api.portalUploadChunk({auth:admin,data:{version,index:0,payload:'AAAA'}}),e=>e.code==='permission-denied');
  await api.portalUploadChunk({auth:user,data:{version,index:0,payload:Buffer.from(JSON.stringify(next)).toString('base64')}});
  await api.portalCommitUpload({auth:user,data:{version,expected:oldVersion,actor:{name:'Fake Admin'}}});
  assert.equal(store.get(root+'/workspace/current').version,version);const manifest=store.get(root+'/versions/'+version);assert.equal(manifest.actor.name,'Captain');assert.equal(manifest.committedAt.toISOString(),'2026-10-11T08:43:37.000Z');
  const entries=[...store.entries()].filter(([path])=>new RegExp('/versions/'+version+'/audit/\\d+$').test(path)).map(([,data])=>data);assert.equal(entries.length,1);assert.equal(entries[0].chapter,'1');
  const pieces=[...store.entries()].filter(([path])=>path.includes('/versions/'+version+'/audit/000000/fragments/')).map(([,data])=>data);assert(pieces.some(p=>p.kind==='added'&&p.text.includes('captain')));assert(pieces.some(p=>p.kind==='removed'&&p.text.includes('pilot')));
  assert(store.has(root+'/versions/'+oldVersion+'/chunks/00000'));
  await assert.rejects(api.portalUploadChunk({auth:user,data:{version,index:0,payload:'AAAA'}}),e=>e.code==='permission-denied');
  const stale='stale-version-12345';await api.portalStartUpload({auth:user,data:{version:stale,count:1,encoding:'json'}});await api.portalUploadChunk({auth:user,data:{version:stale,index:0,payload:Buffer.from(JSON.stringify(next)).toString('base64')}});
  await assert.rejects(api.portalCommitUpload({auth:user,data:{version:stale,expected:oldVersion}}),/another device/);assert.equal(store.get(root+'/workspace/current').version,version);
});

test('only admin may delete, clear, restore or inspect deleted logs; manual snapshots survive',async()=>{
  const version='new-version-12345',entryId='000000',data={action:'delete',version,entryId};
  const metaBefore=clone(store.get(root+'/workspace/current')),chunksBefore=clone(store.get(root+'/versions/'+version+'/chunks/00000'));
  await assert.rejects(api.portalManageRevisions({auth:user,data}),e=>e.code==='permission-denied');
  await assert.rejects(api.portalManageRevisions({auth:user,data:{action:'clear'}}),e=>e.code==='permission-denied');
  await assert.rejects(api.portalListRevisions({auth:user,data:{deleted:true}}),e=>e.code==='permission-denied');
  assert.equal((await api.portalListRevisions({auth:user,data:{}})).rows.length,1);
  await api.portalManageRevisions({auth:admin,data});
  assert.equal((await api.portalListRevisions({auth:user,data:{}})).rows.length,0);
  assert.equal((await api.portalListRevisions({auth:admin,data:{deleted:true}})).rows.length,1);
  await assert.rejects(api.portalRevisionDetail({auth:user,data:{version,entryId}}),e=>e.code==='not-found');
  await assert.rejects(api.portalRevisionDetail({auth:user,data:{version,entryId,deleted:true}}),e=>e.code==='permission-denied');
  assert((await api.portalRevisionDetail({auth:admin,data:{version,entryId,deleted:true}})).added.includes('captain'));
  clock='2026-10-11T08:43:38Z';await api.portalManageRevisions({auth:admin,data:{...data,action:'restore'}});
  assert.equal((await api.portalListRevisions({auth:user,data:{}})).rows.length,1);
  clock='2026-10-11T08:43:39Z';await api.portalManageRevisions({auth:admin,data:{action:'clear'}});
  assert.equal((await api.portalListRevisions({auth:user,data:{}})).rows.length,0);
  clock='2026-10-11T08:43:40Z';await api.portalManageRevisions({auth:admin,data:{...data,action:'restore'}});
  assert.equal((await api.portalListRevisions({auth:user,data:{}})).rows.length,1);
  const newer='newer-version-12345';store.set(root+'/versions/'+newer,{status:'committed',createdAt:new Date(clock),committedAt:new Date(clock),actor:{name:'Captain',username:'captain'}});store.set(root+'/versions/'+newer+'/audit/000000',{manual:'B',chapter:'2',page:'2 - 1',action:'edited'});
  assert.equal((await api.portalListRevisions({auth:user,data:{}})).rows.length,2,'New edits remain visible after clear');
  assert.deepEqual(store.get(root+'/workspace/current'),metaBefore);assert.deepEqual(store.get(root+'/versions/'+version+'/chunks/00000'),chunksBefore);
  await assert.rejects(api.portalManageRevisions({auth:admin,data:{...data,entryId:'bad/path'}}));
  await assert.rejects(api.portalManageRevisions({auth:admin,data:{...data,entryId:'999999'}}),e=>e.code==='not-found');
});

test('additional manuals are persisted, audited under their own name and cannot damage OM A-D',async()=>{
  const expected=store.get(root+'/workspace/current').version,version='manual-library-version-12345';
  const next=workspace('<p>The captain inspects the aircraft.</p>');
  next.manuals['manual-cmm-12345']={title:'Company Maintenance Manual',code:'CMM',label:'CMM',ref:'TWA-CMM',number:'{ref} / {chapter}-{page}',start:1,frontTemplateVersion:1,hiddenFront:['letter','dkppu'],front:Object.fromEntries(['cover','control','loep','record','toc'].map(id=>[id,{rev:'0',date:'2026-10-11',bars:[]}])),pages:[{id:'cmm-page-12345',title:'Maintenance Policy',chapter:'1',rev:'0',date:'2026-10-11',html:'<p>Maintenance team checks the aircraft.</p>',bars:[]}]};
  await api.portalStartUpload({auth:user,data:{version,count:1,encoding:'json'}});
  await api.portalUploadChunk({auth:user,data:{version,index:0,payload:Buffer.from(JSON.stringify(next)).toString('base64')}});
  await api.portalCommitUpload({auth:user,data:{version,expected}});
  const entries=[...store.entries()].filter(([p])=>new RegExp('/versions/'+version+'/audit/\\d+$').test(p)).map(([,data])=>data);
  assert(entries.some(e=>e.manual==='manual-cmm-12345'&&e.manualName==='CMM'&&e.page==='TWA-CMM / 1-1'));
  assert(entries.some(e=>e.manual==='manual-cmm-12345'&&e.pageId==='control'));
  assert(!entries.some(e=>['A','B','C','D'].includes(e.manual)));
  const stored=JSON.parse(Buffer.from(store.get(root+'/versions/'+version+'/chunks/00000').payload,'base64').toString('utf8'));assert.deepEqual(stored.manuals['manual-cmm-12345'],next.manuals['manual-cmm-12345']);
  const invalid='invalid-library-version-12345';next.manuals['manual-cmm-12345'].pages=null;
  await api.portalStartUpload({auth:user,data:{version:invalid,count:1,encoding:'json'}});await api.portalUploadChunk({auth:user,data:{version:invalid,index:0,payload:Buffer.from(JSON.stringify(next)).toString('base64')}});
  await assert.rejects(api.portalCommitUpload({auth:user,data:{version:invalid,expected:version}}),/Format manual/);assert.equal(store.get(root+'/workspace/current').version,version);
});
