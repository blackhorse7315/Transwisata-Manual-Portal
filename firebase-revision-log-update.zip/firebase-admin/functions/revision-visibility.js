'use strict';
function millis(value){if(!value)return 0;if(typeof value.toMillis==='function')return value.toMillis();return value instanceof Date?value.getTime():Date.parse(value)||0;}
function isDeleted(version,entry,policy={}){if(entry.deletedAt)return true;const cutoff=millis(policy.clearedAt);return cutoff>0&&millis(version.committedAt)<=cutoff&&millis(entry.restoredAt)<=cutoff;}
module.exports={isDeleted};
